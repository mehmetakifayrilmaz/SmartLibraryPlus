package com.kutuphane.app;

import com.kutuphane.dao.BookDao;
import com.kutuphane.dao.LoanDao;
import com.kutuphane.dao.StudentDao;
import com.kutuphane.entity.Book;
import com.kutuphane.entity.Loan;
import com.kutuphane.entity.Student;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        // --- 🔇 KIRMIZI YAZILARI SUSTURAN KOD ---
        Logger.getLogger("org.hibernate").setLevel(Level.OFF);
        // ----------------------------------------

        Scanner scanner = new Scanner(System.in);
        BookDao bookDao = new BookDao();
        StudentDao studentDao = new StudentDao();
        LoanDao loanDao = new LoanDao();

        while (true) {
            System.out.println("\n=== 📚 SMART LIBRARY SİSTEMİ (V2.0) ===");
            System.out.println("1 - Kitap Ekle");
            System.out.println("2 - Kitapları Listele");
            System.out.println("3 - Öğrenci Ekle");
            System.out.println("4 - Öğrencileri Listele");
            System.out.println("5 - Kitap Ödünç Ver");
            System.out.println("6 - Ödünç Listesini Görüntüle");
            System.out.println("7 - Kitap Geri Teslim Al");
            System.out.println("---------------------------");
            System.out.println("8 - Kitap Sil 🗑️");
            System.out.println("9 - Kitap Düzenle ✏️");
            System.out.println("10 - Öğrenci Sil 🗑️");
            System.out.println("11 - Öğrenci Düzenle ✏️");
            System.out.println("0 - Çıkış ❌");
            System.out.print("Seçiminiz: ");

            int choice;
            try {
                // Menü seçimi için güvenlik
                String input = scanner.next();
                choice = Integer.parseInt(input);
                scanner.nextLine(); // Buffer temizliği
            } catch (Exception e) {
                System.out.println("\n⚠️ Lütfen sadece menüdeki sayıları giriniz!");
                scanner.nextLine(); // Hatalı girdiyi temizle
                continue; // Başa dön
            }

            if (choice == 0) {
                System.out.println("Sistemden çıkılıyor... İyi günler!");
                break;
            }

            // --- 🛡️ BÜYÜK GÜVENLİK KALKANI (TRY-CATCH) ---
            // Bu blok içindeki herhangi bir işlemde (Yıl, ID vs.) hata olursa program çökmez.
            try {
                switch (choice) {
                    case 1:
                        System.out.print("Kitap Adı: ");
                        String title = scanner.nextLine();
                        System.out.print("Yazar: ");
                        String author = scanner.nextLine();
                        System.out.print("Yıl (Sadece Rakam): ");
                        int year = scanner.nextInt(); // Hata olursa catch yakalar
                        Book newBook = new Book(title, author, year, "AVAILABLE");
                        bookDao.save(newBook);
                        System.out.println("✅ Kitap başarıyla eklendi!");
                        break;

                    case 2:
                        List<Book> books = bookDao.getAll();
                        System.out.println("\n--- 📖 KİTAP LİSTESİ ---");
                        for (Book b : books) {
                            System.out.println(b);
                        }
                        break;

                    case 3:
                        System.out.print("Öğrenci Adı: ");
                        String sName = scanner.nextLine();
                        System.out.print("Bölüm: ");
                        String dept = scanner.nextLine();
                        Student newStudent = new Student(sName, dept);
                        studentDao.save(newStudent);
                        System.out.println("✅ Öğrenci eklendi!");
                        break;

                    case 4:
                        List<Student> students = studentDao.getAll();
                        System.out.println("\n--- 🎓 ÖĞRENCİ LİSTESİ ---");
                        for (Student s : students) {
                            System.out.println(s);
                        }
                        break;

                    case 5:
                        System.out.print("Öğrenci ID: ");
                        Long sId = scanner.nextLong();
                        System.out.print("Kitap ID: ");
                        Long bId = scanner.nextLong();
                        Student student = studentDao.getById(sId);
                        Book book = bookDao.getById(bId);

                        if (student != null && book != null) {
                            if ("BORROWED".equals(book.getStatus())) {
                                System.out.println("⚠️ HATA: Bu kitap zaten başkasında!");
                            } else {
                                book.setStatus("BORROWED");
                                bookDao.update(book);
                                Loan loan = new Loan(LocalDate.now(), book, student);
                                loanDao.save(loan);
                                System.out.println("✅ Kitap ödünç verildi.");
                            }
                        } else {
                            System.out.println("❌ Hatalı ID girdiniz.");
                        }
                        break;

                    case 6:
                        List<Loan> loans = loanDao.getAll();
                        System.out.println("\n--- 📋 ÖDÜNÇ LİSTESİ ---");
                        for (Loan l : loans) {
                            System.out.println(l);
                        }
                        break;

                    case 7:
                        System.out.print("İade edilecek Kitap ID: ");
                        Long returnBookId = scanner.nextLong();
                        Book returnBook = bookDao.getById(returnBookId);

                        if (returnBook != null && "BORROWED".equals(returnBook.getStatus())) {
                            returnBook.setStatus("AVAILABLE");
                            bookDao.update(returnBook);
                            List<Loan> allLoans = loanDao.getAll();
                            for (Loan l : allLoans) {
                                if (l.getBook().getId().equals(returnBookId) && l.getReturnDate() == null) {
                                    l.setReturnDate(LocalDate.now());
                                    loanDao.update(l);
                                    System.out.println("✅ Kitap iade alındı.");
                                    break;
                                }
                            }
                        } else {
                            System.out.println("❌ Bu kitap zaten kütüphanede veya bulunamadı.");
                        }
                        break;

                    case 8: // KİTAP SİLME
                        System.out.print("Silinecek Kitap ID: ");
                        Long delBookId = scanner.nextLong();
                        Book bookToDelete = bookDao.getById(delBookId);
                        if (bookToDelete != null) {
                            String silinenKitap = bookToDelete.getTitle();
                            bookDao.delete(delBookId);
                            System.out.println("✅ '" + silinenKitap + "' kitabı başarıyla silindi.");
                        } else {
                            System.out.println("❌ Kitap bulunamadı.");
                        }
                        break;

                    case 9: // KİTAP DÜZENLEME
                        System.out.print("Düzenlenecek Kitap ID: ");
                        Long editBookId = scanner.nextLong();
                        scanner.nextLine();
                        Book bookToEdit = bookDao.getById(editBookId);
                        if (bookToEdit != null) {
                            System.out.println("Mevcut Başlık: " + bookToEdit.getTitle());
                            System.out.print("Yeni Başlık: ");
                            String newTitle = scanner.nextLine();
                            if (!newTitle.isEmpty()) bookToEdit.setTitle(newTitle);

                            System.out.println("Mevcut Yazar: " + bookToEdit.getAuthor());
                            System.out.print("Yeni Yazar: ");
                            String newAuthor = scanner.nextLine();
                            if (!newAuthor.isEmpty()) bookToEdit.setAuthor(newAuthor);

                            bookDao.update(bookToEdit);
                            System.out.println("✅ Kitap güncellendi!");
                        } else {
                            System.out.println("❌ Kitap bulunamadı.");
                        }
                        break;

                    case 10: // ÖĞRENCİ SİLME
                        System.out.print("Silinecek Öğrenci ID: ");
                        Long delStId = scanner.nextLong();
                        Student stDel = studentDao.getById(delStId);
                        if (stDel != null) {
                            String silinenOgrenci = stDel.getName();
                            studentDao.delete(delStId);
                            System.out.println("✅ '" + silinenOgrenci + "' isimli öğrenci silindi.");
                        } else {
                            System.out.println("❌ Öğrenci bulunamadı.");
                        }
                        break;

                    case 11: // ÖĞRENCİ DÜZENLEME
                        System.out.print("Düzenlenecek Öğrenci ID: ");
                        Long edStId = scanner.nextLong();
                        scanner.nextLine();
                        Student stEd = studentDao.getById(edStId);
                        if (stEd != null) {
                            System.out.println("Mevcut İsim: " + stEd.getName());
                            System.out.print("Yeni İsim: ");
                            String nName = scanner.nextLine();
                            if (!nName.isEmpty()) stEd.setName(nName);

                            System.out.println("Mevcut Bölüm: " + stEd.getDepartment());
                            System.out.print("Yeni Bölüm: ");
                            String nDept = scanner.nextLine();
                            if (!nDept.isEmpty()) stEd.setDepartment(nDept);

                            studentDao.update(stEd);
                            System.out.println("✅ Öğrenci güncellendi!");
                        } else {
                            System.out.println("❌ Öğrenci bulunamadı.");
                        }
                        break;

                    default:
                        System.out.println("⚠️ Geçersiz seçim.");
                }

            } catch (Exception e) {
                // HATA YAKALAMA MERKEZİ 🚑
                System.out.println("\n❌ HATA: Geçersiz bir değer girdiniz (Harf veya sembol)!");
                System.out.println("🔄 Ana menüye dönülüyor...");
                scanner.nextLine(); // Hatalı girdiyi temizle ki sonsuz döngü olmasın
            }
        }
    }
}