package com.kutuphane.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.kutuphane.entity.Book;
import com.kutuphane.entity.Student;
import com.kutuphane.entity.Loan;

public class HibernateUtil {
    private static SessionFactory sessionFactory;

    static {
        try {
            // Ayarları yükle ve veritabanı bağlantısını hazırla
            sessionFactory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Book.class)
                    .addAnnotatedClass(Student.class)
                    .addAnnotatedClass(Loan.class)
                    .buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("Veritabanı bağlantısı kurulamadı: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}