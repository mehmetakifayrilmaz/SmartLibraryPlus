package com.kutuphane.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "loans")
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate borrowDate; // Alış Tarihi
    private LocalDate returnDate; // İade Tarihi

    // Hangi kitap? (OneToOne)
    @OneToOne
    @JoinColumn(name = "book_id", referencedColumnName = "id")
    private Book book;

    // Kim aldı? (ManyToOne)
    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    public Loan() {
    }

    public Loan(LocalDate borrowDate, Book book, Student student) {
        this.borrowDate = borrowDate;
        this.book = book;
        this.student = student;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate borrowDate) { this.borrowDate = borrowDate; }

    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }

    public Book getBook() { return book; }
    public void setBook(Book book) { this.book = book; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    @Override
    public String toString() {
        return "İşlem [Kitap=" + book.getTitle() + ", Alan=" + student.getName() + ", Tarih=" + borrowDate + "]";
    }
}